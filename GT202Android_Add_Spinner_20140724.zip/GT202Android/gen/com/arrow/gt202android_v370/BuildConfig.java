/** Automatically generated file. DO NOT MODIFY */
package com.arrow.gt202android_v370;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}